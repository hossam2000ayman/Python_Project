
"""
Empty Graph Template to implement :D

YouTube Kylie Ying: https://www.youtube.com/ycubed 
Twitch KylieYing: https://www.twitch.tv/kylieying 
Twitter @kylieyying: https://twitter.com/kylieyying 
Instagram @kylieyying: https://www.instagram.com/kylieyying/ 
Website: https://www.kylieying.com
Github: https://www.github.com/kying18 
Programmer Beast Mode Spotify playlist: https://open.spotify.com/playlist/4Akns5EUb3gzmlXIdsJkPs?si=qGc4ubKRRYmPHAJAIrCxVQ 
"""

import random

class Vertex(object):
    def __init__(self, value):
        pass

    def add_edge_to(self, vertex, weight=0):
        pass

    def increment_edge(self, vertex):
        pass

    def get_adjacent_nodes(self):
        pass

    # initializes probability map
    def get_probability_map(self):
        pass

    def next_word(self):
        pass



class Graph(object):
    def __init__(self):
        pass

    def get_vertex_values(self):
        pass

    def add_vertex(self, value):
        pass

    def get_vertex(self, value):
        pass

    def get_next_word(self, current_vertex):
        pass

    def generate_probability_mappings(self):
        pass
